﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace outlook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Outlook._Application olApp = (Outlook._Application)new Outlook.Application();
            Outlook.NameSpace mapins = olApp.GetNamespace("MAPI");
            mapins.Logon("", null, null, null);
            Microsoft.Office.Interop.Outlook.Application OlApp = new Microsoft.Office.Interop.Outlook.Application();
            Outlook.NameSpace OLNamespace = OlApp.GetNamespace("MAPI");
            Outlook.MAPIFolder AppointmentFolder =OLNamespace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderCalendar);
            AppointmentFolder.Items.IncludeRecurrences = true;
            Outlook.Items calenderitems = AppointmentFolder.Items;
            Outlook.AppointmentItem item = calenderitems[textBox1.Text] as Outlook.AppointmentItem;
            item.MeetingStatus = Outlook.OlMeetingStatus.olMeetingCanceled;
            item.ForceUpdateToAllAttendees = true;
            item.Delete();

        }
    }
}
